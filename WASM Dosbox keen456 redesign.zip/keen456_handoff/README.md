# Handoff: Commander Keen 4·5·6 Launcher — multi-game "Console" redesign

## Overview
This redesigns the **launcher page** for a browser build of *Commander Keen 4, 5 and 6* (js-dos / DOSBox → WebAssembly). The launcher is the shell the player sees **before** a game boots; pressing **Play** swaps it out for the full-screen emulator canvas.

The app bundles **three separate games**, and the previous UI (a single-game layout carried over from the Zeliard launcher) couldn't express that. This redesign makes the three games first-class:

- A **game-selector bar** at the top (Keen 4 / Keen 5 / Keen 6). Selecting a game switches the whole Play surface to that game.
- **Saved game** and **Server sync** are **per game** — separate save slot, separate sync key, separate device list, separate on/off toggle, separate first-sync conflict popup.
- **Settings** and **How to play** are **global** — one shared copy that applies to all three games.

Identity: deep indigo background, gold (`#f5c542`) primary accent, teal (`#57b6e8`) for codes/links/the "4·5·6". Each game also carries a small signature accent — Keen 4 `#57b6e8` (blue), Keen 5 `#f07a7a` (red), Keen 6 `#6ee0a0` (green) — used on its selector tab, its "Keen N" badges, and its poster glow, so switching games is visibly obvious.

## About the design file
`Keen 456 — Console.dc.html` is a **working design reference / prototype** — it shows the intended look, layout, and interactions, and you can open it in a browser to click through every state. **It is not production code to ship as-is.** It's authored in a lightweight in-house template format (an `<x-dc>` template + a `Component` logic class); **do not** try to run or import that format in the real app.

Your task: **recreate this UI inside the actual Keen launcher codebase**, reusing its existing patterns. The real app already has the js-dos boot logic, the IndexedDB save store, the server-sync fetch calls, and the settings persistence — **keep all of that**. This redesign changes the **markup + styling + the navigation/tab shell + the per-game data model on the front end**. Wire the new controls to the **existing** backend functions (boot game, download/upload/delete save, copy key, link key, toggle sync, change settings).

## The one real behavioral change: per-game state
Previously the launcher tracked a single save + single sync key. Now the front end must key those by game id (`keen4` / `keen5` / `keen6`):
- **Save slot per game** — each game's save is stored, downloaded, uploaded, and deleted independently. Keen 4 is free shareware (bundled); Keen 5/6 require the user to supply their own game data files, so a game may be playable-with-saves OR in a "no save yet" empty state.
- **Sync key per game** — each game has its own server key and its own enabled/disabled flag. Linking a device, pushing/pulling, and the conflict resolution all operate on **one game at a time**; the other two games are untouched.
- **The first-sync conflict popup is per game** — it names the game and shows that game's key.

If the existing sync backend uses one key for the whole browser, it needs to become one key **per game** (three keys). Confirm this with the app owner — it's the core data-model change behind the UI.

## Fidelity
**High-fidelity.** Colors, type, spacing, radii, and interactions are final — match them. The hero "screen" in each game's Play view is intentionally a **decorative poster** (gradient + scanlines + "KEEN" title), not live gameplay or video; a static title-screen screenshot per game is a fine substitute.

---

## Information architecture

```
Top bar:  [KEEN 4·5·6] [BROWSER EDITION badge] ............. How to play | Settings
Game bar: [ KEEN 4 ] [ KEEN 5 ] [ KEEN 6 ]   ← selecting a game = Play view for that game
Content:  Play (per selected game)  |  How to play (global)  |  Settings (global)
```

- The top-right **How to play** / **Settings** are global views. When one is open, no game tab is highlighted.
- Selecting any **game tab** returns to the Play view for that game (a game tab is highlighted only while the Play view is showing).
- State model: `view ∈ {play, howto, settings}` and `game ∈ {keen4, keen5, keen6}`. Game tab `x` is "active" only when `view===play && game===x`.

### Per-game data (as shown in the prototype)
| Game | Title | Files | Save state | Sync key | Sync default |
|---|---|---|---|---|---|
| Keen 4 | Secret of the Oracle | Free shareware (bundled) | 842 KB | `7F2A-9QKR-V5VK-R2DE` | On (This Mac · now; iPhone · 2d) |
| Keen 5 | The Armageddon Machine | Supply your own | 1.1 MB | `K5LM-3PQU-8WXZ-T1BN` | On (This Mac · now) |
| Keen 6 | Aliens Ate My Babysitter! | Supply your own | none yet | `6HJD-UPQU-V5VK-9QKR` | Off |

(Those exact values are demo data — real keys/sizes/devices come from the backend.)

---

## Color tokens
| Token | Hex | Use |
|---|---|---|
| Background | `radial-gradient(circle at 50% -10%, #1a1640, #0a0820 60%)` | page |
| Frame bg | `linear-gradient(180deg,#120f2c,#0d0a24)` | desktop frame / phone body |
| Card | `#171234` | all cards |
| Card border | `rgba(255,255,255,.07)` | all cards |
| Inset / control bg | `rgba(0,0,0,.3)` | key field, selects, segmented tracks |
| Inset border | `#2c2552` / `#322a5a` | inset & button borders |
| Gold (primary) | `#f5c542` | wordmark, active states, save size, play btn |
| Play button | `linear-gradient(180deg,#f7cf54,#e8a93c)`, text `#1a1206` | primary CTA |
| Teal | `#57b6e8` | "4·5·6", sync keys, links, keycaps |
| Green (synced/ok) | `#6ee0a0` | synced status, on-toggle |
| Red (delete/Keen5) | text `#ff9ab5` on `#3a1a2a` / border `#5a2a40` | delete button |
| Text primary | `#e9eaf5` | headings |
| Text body | `#a9a7cf` / `#c9c7e6` | paragraphs, labels |
| Text muted | `#8a88b5` / `#6a6796` | captions, inactive |
| Game accents | Keen4 `#57b6e8` · Keen5 `#f07a7a` · Keen6 `#6ee0a0` | per-game identity |

Type: **Manrope** (UI, weights 400–800) and **JetBrains Mono** (sync keys + keycaps). Both from Google Fonts.

---

## Components & screens

### Top bar
- flex row, `space-between`, padding `16px 26px`, bottom border `1px solid rgba(255,255,255,.06)`.
- Left: `KEEN` (Manrope 800, 21px, letter-spacing 4px, `#f5c542`) + `4·5·6` (teal `#57b6e8`) + `BROWSER EDITION` pill badge (600 10px, `#8a88b5`, border `#322a5a`, radius 5px).
- Right: two global nav buttons **How to play** / **Settings**. Active = `background:rgba(245,197,66,.14); color:#f5c542; weight 700`; inactive = transparent `#9a98c0` weight 600; padding `8px 16px`, radius 9px.

### Game-selector bar
- Small uppercase label "CHOOSE GAME" (`#6a6796`, 11px, letter-spacing 1.4px) + a hairline rule, then a flex row of **3 equal-width tabs** (`gap:12px`).
- Each tab (`flex:1`, padding `13px 16px`, radius 14px, left-aligned):
  - Row: `KEEN N` (Manrope 800 18px — `#f5c542` when active, else `#c9c7e6`) + a small "Free" / "Your files" label (`#8a88b5`).
  - Subtitle: game title (600 12.5px `#c9c7e6`).
  - Status chip: a 7px dot + text — **Synced** (`#6ee0a0`) when that game's sync is on, **Local only** (`#8a88b5`, gray dot) when off.
  - Active tab: `background:rgba(245,197,66,.10); border:1.5px solid <gameAccent>; box-shadow:0 0 0 1px <gameAccent>33`. Inactive: `background:rgba(0,0,0,.22); border:1.5px solid #2c2552`.

### Play view (per game) — desktop grid `1.6fr 1fr`, gap 18px
- **Hero card** (`#171234`, radius 18px):
  - **Poster** (height 272px, `background:#08061a`): per-game radial gradient (`posterBg`) + scanline overlay `repeating-linear-gradient(0deg, transparent 0 2px, rgba(0,0,0,.3) 3px, transparent 4px)`. Centered: `KEEN` (Manrope 800, 46px, letter-spacing 8px, `#f5c542`, glow `0 0 30px #f5c54255`); the game's `heroSub` line in teal (e.g. "GOODBYE, GALAXY!" for 4/5, "ALIENS ATE MY BABYSITTER!" for 6); a 62px gold play circle. **Decorative poster — swap for a real screenshot if desired.**
  - **Footer row**: description text (`#a9a7cf` 14px) + teal "load your files →" link (Keen 5/6) + primary **▶ Play Keen N — Title** button (gold gradient, radius 12px, 800 15px, `color:#1a1206`).
- **Right rail** (vertical, gap 18px):
  - **Saved game card** — title "Saved game" + a `Keen N` badge tinted with the game accent. If a save exists: big size readout (Manrope 800 26px `#f5c542`) + Download / Upload / Delete buttons (Download/Upload `#221c44`/border `#322a5a`; Delete red). If no save: a dashed empty-state box ("No saved game yet — play to create one, or upload a .jsdos") + an "⤒ Upload a saved game" button.
  - **Server sync card** — header "Server sync" + `Keen N` badge + a **toggle switch** (track 42×24, on `#6ee0a0`, off `#4a4570`; 18px white knob translating 18px). Sub-note "Each game has its own key — link them independently." Key field (mono 700 13px teal, ellipsis) + Copy button (shows "Copied!" 1.2s). **If sync on:** device list (dot + name + relative time) and a dashed **+ Link another device** button (opens the conflict modal). **If sync off:** an inset note "Sync is off for Keen N — this save stays in this browser only…". Status line below.

### How to play (global)
- Single card; header "Controls" + "same for all three games".
- Controls grid `1fr 1fr`, gap `13px 40px`. Keycap style: `height:24px; padding:0 8px; background:rgba(0,0,0,.4); border:1px solid #322a5a; border-bottom-width:2px; border-radius:6px; font:700 12px JetBrains Mono; color:#57b6e8`. Labels Manrope 500 13.5px `#a9a7cf`.
  - `← →` walk · `Ctrl` jump · `Alt` pogo stick · `Space` fire/shoot · `↑ ↓` look up/down · enter doors · `Enter` confirm · `Esc` menu/pause · `F2` save · `F3` load (in-game menu) · `F10`+`Y` quit to map.
- Footer note (`#8a88b5` 13px): save via in-game menu (Esc → Save Game); mobile split-screen with joystick + Shoot/Pogo/Jump; **Pogo** fires Pogo+Jump together for the high super-bounce.

### Settings (global)
- Single card; header "Settings" + "global · apply to all three games · saved automatically".
- Grid `1fr 1fr`, gap `20px 44px`; each row = label (`#c9c7e6` 600 13.5px) + control, `space-between`.
- **Segmented controls** (wrapper `background:rgba(0,0,0,.3); border:1px solid #322a5a; border-radius:11px; padding:3px`; selected segment `background:#f5c542; color:#1a1206; weight 700`; unselected transparent `#9a98c0`; segment padding `7px 14px`, radius 8px):
  - **Engine:** DOSBox / DOSBox-X (default **DOSBox**)
  - **Pixels:** Crisp / Smooth (default Crisp)
  - **Touch controls:** Auto / On / Off (default Auto)
- **Native `<select>`** (styled: `min-width:210px; padding:9px 12px; background:rgba(0,0,0,.3); color:#e9eaf5; border:1px solid #322a5a; border-radius:11px; 600 12.5px`):
  - **Aspect ratio:** 4:3 — classic CRT (default) · As-is — sharp · 16:10 · 16:9 — widescreen · Fit window
  - **Screen filter:** Off — crisp pixels (default) · Scanlines · CRT — scanlines + mask + vignette · Soft — blurry pixels · Amber — monochrome
  - **Pogo auto-retract:** Off · 120 ms · 150 ms · **180 ms (default)** · 240 ms · 300 ms
- **Toggle:** Pogo on desktop Alt (default off) — same switch component as sync.

### Per-game first-sync conflict modal
Trigger: a device links a game's sync key that **already has a cloud save** AND this browser also has a local save for that game. Shown once at link time per game — not an always-on control.
- Overlay `position:fixed; inset:0; background:rgba(8,6,22,.74)`; click overlay = cancel; click dialog = no-op (`stopPropagation`).
- Dialog width 600px, `#171234`, radius 22px, big shadow.
- Header: a game badge ("Keen N — Title", tinted with game accent) + "Two saves found for this key" (Manrope 800 21px) + explainer naming that game's key, ending "Your other Keen games are unaffected."
- **Two choice tiles** (grid `1fr 1fr`, gap 14px), each padding `20px 18px`, radius 16px, selectable (radio-style ✓ in a gold circle when chosen; gray ring when not). Selected tile: `border:2px solid #f5c542; background:rgba(245,197,66,.08)`. Unselected: `border:2px solid #322a5a; background:rgba(0,0,0,.22)`.
  - **Cloud save** (☁) — size from server — "Downloads & replaces this browser's Keen N save."
  - **This browser** (💾) — local size — "Uploads & replaces Keen N's cloud copy."
- Footer: **Cancel** (ghost) + primary **Keep cloud save** / **Keep this browser** (label follows the selection).

### Mobile (382-wide frame in the prototype)
- **Top bar:** `KEEN 4·5·6` wordmark + a status pill for the **current** game ("Keen N synced" green / "Keen N local" gray).
- **Game switcher row** (under the header): a 3-segment pill **Keen 4 / Keen 5 / Keen 6** (selected = gold). Shown on Play / Saves / Sync. On the Guide and Settings tabs it's replaced by a global label chip ("Same controls for all games" / "Global settings — apply to all games").
- **Scroll body** holds the active mobile tab's content (Play poster + CTA; Saves card; Sync card; Guide controls; global Settings) — all the same components as desktop, single-column, with segmented controls stacked full-width (label above, segments `flex:1`).
- **Bottom tab bar** (5 tabs): **Play / Saves / Sync / Guide / Settings** — glyph (17px) + label (Manrope 700 9.5px). Active glyph opacity 1 + label `#f5c542`; inactive opacity .5 + label `#6a6796`. `mView` drives this; the game switcher drives `game`. Saves/Sync reflect the selected game; Guide/Settings are global.

---

## Implementation notes
- **Reuse existing backend.** New UI, same js-dos boot, IndexedDB saves, sync fetches, settings persistence — but saves & sync keys become **keyed by game id**.
- **Inline styles in the prototype are for spec only** — translate to the app's existing CSS approach (the original used CSS custom properties + classes in `app.css`); add `--game-accent` style tokens or per-game classes as convenient.
- **Native `<select>`** for the many-option settings (aspect/filter/pogo) is intentional — keeps them compact on mobile (the original oversized-dropdown problem). Use **segmented pills** only for 2–3 option settings.
- **Accessibility:** the segmented controls and game tabs should be real buttons with `aria-pressed`; the modal needs focus trap + Esc-to-cancel; the toggle switches need `role="switch"` + `aria-checked`.
- The decorative posters are placeholders — wire in a real per-game screenshot if you have art.

## Files in this bundle
- `Keen 456 — Console.dc.html` — the interactive design reference (open in a browser to click through all states: switch games, toggle each game's sync, open the per-game conflict modal, change global settings, and the mobile frame).
- `README.md` — this spec.
